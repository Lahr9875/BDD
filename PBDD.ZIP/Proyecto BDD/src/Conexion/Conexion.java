package Conexion;
import java.sql.*;
import javax.swing.*;

public class Conexion {
    Connection conect = null;
    public Connection conexion(){
            try {
                //Cargamos el Driver MySQL
                Class.forName("com.mysql.jdbc.Driver");
                conect = DriverManager.getConnection("jdbc:mysql://localhost/bdd","root","esnake01");
                //JOptionPane.showMessageDialog(null,"Conectado");
                
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("error de conexion");
                JOptionPane.showMessageDialog(null,"Error de conexion"+e);
            }
            return conect;
        }
     
}