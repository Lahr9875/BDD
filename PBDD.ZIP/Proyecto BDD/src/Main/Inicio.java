package Main;
import Interfaz.Principal;
/**
 *
 * @author lahr9
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Principal oPrincipal = new Principal();
        oPrincipal.setVisible(true);
    }
    
}
